package net.khangquach.practicemod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.khangquach.practicemod.entity.ModEntities;
import net.khangquach.practicemod.entity.client.DragonRenderer;
import net.khangquach.practicemod.entity.client.HedgehogRenderer;

public class PracticeModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.HEDGEHOG, HedgehogRenderer::new);
        EntityRendererRegistry.register(ModEntities.DRAGON, DragonRenderer::new);
    }
}
