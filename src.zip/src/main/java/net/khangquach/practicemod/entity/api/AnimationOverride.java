package net.khangquach.practicemod.entity.api;

import net.minecraft.util.math.Vec3d;

public record AnimationOverride(Vec3d localPos, float scaleW, float scaleH) {
}
