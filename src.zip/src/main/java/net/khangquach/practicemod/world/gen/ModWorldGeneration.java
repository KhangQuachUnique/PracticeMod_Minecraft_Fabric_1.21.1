package net.khangquach.practicemod.world.gen;

import net.khangquach.practicemod.entity.ModEntities;

public class ModWorldGeneration {
    public static void generateWorldModGen() {
        ModEntitySpawns.addSpawns();
    }
}
