package net.khangquach.practicemod.datagen;

public class ModModelProvider {
}
