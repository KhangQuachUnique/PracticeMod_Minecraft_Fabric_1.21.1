// == Base Hitbox Entity ==
package net.khangquach.practicemod.entity.custom;

import com.google.common.collect.Lists;
import net.khangquach.practicemod.PracticeMod;
import net.minecraft.entity.*;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class HitboxPartEntity extends Entity {
    private final EntityDimensions dimensions;
    private final Entity parent;
    private final String partName;
    private final float width;
    private final float height;

    public HitboxPartEntity(Entity parent, String partName, float width, float height) {
        super(EntityType.ARMOR_STAND, parent.getWorld()); // Dummy type, replace with your own
        this.parent = parent;
        this.partName = partName;
        this.width = width;
        this.height = height;
        this.noClip = false;
        this.dimensions = EntityDimensions.changing(width, height);
        this.setBoundingBox(new Box(0, 0, 0, width, height, width));
    }

    public float getCustomWidth() {
        return this.width;
    }

    public float getCustomHeight() {
        return this.height;
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {

    }

    @Override
    public boolean canHit() {
        return true;
    }

    @Override
    public void tick() {
        if (!this.isAlive() || parent == null || !parent.isAlive()) {
            this.discard();
            return;
        }
        super.tick();
    }

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {}

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {}

    @Override
    public EntityDimensions getDimensions(EntityPose pose) {
        return dimensions;
    }

    @Override
    public boolean isCollidable() {
        return true;
    }

    @Override
    public boolean isPushable() {
        return true;
    }

    @Override
    public boolean shouldRender(double cameraX, double cameraY, double cameraZ) {
        return false;
    }

    @Override
    public boolean shouldRender(double distance) {
        return false;
    }

    @Override
    public void move(MovementType type, Vec3d movement) {
        // Cho phép xử lý va chạm với block cho PartEntity
        if (!this.noClip && movement.lengthSquared() > 0) {
            Vec3d adjusted = Entity.adjustMovementForCollisions(this, movement, this.getBoundingBox(), this.getWorld(), List.of());
            super.move(type, adjusted);
        } else {
            super.move(type, movement);
        }
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        PracticeMod.LOGGER.info("Part " + this.partName + " was hit");
        if (this.parent instanceof DragonEntity dragon) {
            return dragon.handlePartDamage(this.partName, source, amount);
        }
        return false;
    }

}
