package net.khangquach.practicemod.entity.custom;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;

import java.util.*;

public class EntityHitboxData<T extends Entity> {
    private final T parent;
    private final Map<String, MultiPart<T>> parts = new LinkedHashMap<>();
    private Box cullingBox = new Box(0, 0, 0, 1, 1, 1);

    public EntityHitboxData(T parent) {
        this.parent = parent;
    }

    public void addPart(String name, HitboxPartEntity part) {
        parts.put(name, new MultiPart<>() {
            @Override
            public String getName() { return name; }
            @Override
            public Entity getEntity() { return part; }
            @Override
            public T getParent() { return parent; }
        });
    }

    public Collection<MultiPart<T>> getCustomParts() {
        return parts.values();
    }

    public boolean hasCustomParts() {
        return !parts.isEmpty();
    }

    public Box getCullingBounds() {
        return cullingBox;
    }

    public void makeBoundingBoxForCulling() {
        Box result = null;

        for (MultiPart<?> part : this.parts.values()) {
            Box partBox = part.getEntity().getBoundingBox();
            if (result == null) {
                result = partBox;
            } else {
                result = result.union(partBox);
            }
        }

        // fallback nếu chưa spawn part nào
        if (result == null) {
            result = parent.getBoundingBox();
        }

        this.cullingBox = result;
    }


}



