package net.khangquach.practicemod.entity.custom;

import net.minecraft.entity.Entity;

public interface MultiPart<T extends Entity> {
    String getName();
    Entity getEntity();
    T getParent();
}

