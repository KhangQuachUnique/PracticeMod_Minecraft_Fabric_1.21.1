package net.khangquach.practicemod.entity.custom;

import net.minecraft.entity.Entity;

public interface MultiPartEntity<T extends Entity> {
    EntityHitboxData<T> getEntityHitboxData();
}
