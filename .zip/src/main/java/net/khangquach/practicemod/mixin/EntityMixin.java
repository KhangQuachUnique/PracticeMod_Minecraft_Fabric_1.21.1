package net.khangquach.practicemod.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.khangquach.practicemod.entity.custom.EntityHitboxData;
import net.khangquach.practicemod.entity.custom.HitboxPartEntity;
import net.khangquach.practicemod.entity.custom.MultiPart;
import net.khangquach.practicemod.entity.custom.MultiPartEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {

    @Shadow protected abstract Vec3d adjustMovementForCollisions(Vec3d movement);

    @Inject(method = "setBoundingBox", at = @At("HEAD"))
    private void updatePartsOnBoundingBoxSet(Box box, CallbackInfo ci) {
        if (this instanceof MultiPartEntity<?> multi) {
            EntityHitboxData<?> data = multi.getEntityHitboxData();
            if (data != null) {
                data.makeBoundingBoxForCulling();
            }
        }
    }

    @Inject(method = "remove", at = @At("RETURN"))
    public void onRemove(Entity.RemovalReason reason, CallbackInfo ci) {
        Entity self = (Entity)(Object)this;
        if (self instanceof MultiPartEntity<?> multi) {
            for (MultiPart<?> part : multi.getEntityHitboxData().getCustomParts()) {
                part.getEntity().remove(reason);
            }
        }
    }

    @Inject(method = "setId", at = @At("RETURN"))
    public void onSetId(int id, CallbackInfo ci) {
        Entity self = (Entity)(Object)this;
        if (self instanceof MultiPartEntity<?> multi) {
            int i = 1;
            for (MultiPart<?> part : multi.getEntityHitboxData().getCustomParts()) {
                part.getEntity().setId(id + i++);
            }
        }
    }

    @ModifyReturnValue(method = "isCollidable", at = @At("RETURN"))
    public boolean disableCollidable(boolean original) {
        if ((Object)this instanceof MultiPartEntity<?>) return false;
        return original;
    }

    @ModifyReturnValue(method = "getBoundingBox", at = @At("RETURN"))
    public Box changeCullBox(Box original) {
        if ((Object)this instanceof MultiPartEntity<?> multi) {
            return multi.getEntityHitboxData().getCullingBounds();
        }
        return original;
    }

    @Inject(method = "getBoundingBox", at = @At("HEAD"), cancellable = true)
    private void overrideBoundingBox(CallbackInfoReturnable<Box> cir) {
        Entity self = (Entity)(Object)this;

        if (self instanceof HitboxPartEntity part) {
            double x = part.getX();
            double y = part.getY();
            double z = part.getZ();
            float w = part.getCustomWidth();
            float h = part.getCustomHeight();

            cir.setReturnValue(new Box(
                    x - w / 2.0f, y, z - w / 2.0f,
                    x + w / 2.0f, y + h, z + w / 2.0f
            ));
        }
    }

    // Redirect collision logic: parts collide, main ignores
//    @Redirect(
//            method = "move",
//            at = @At(
//                    value = "INVOKE",
//                    target = "Lnet/minecraft/entity/Entity;adjustMovementForCollisions(Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;"
//            )
//    )
//    private Vec3d redirectCollision(Entity self, Vec3d movement) {
//        if (self instanceof HitboxPartEntity) {
//            return this.adjustMovementForCollisions(movement);
//        }
//        return movement;
//    }


}

