// == Mixin vào EntityRenderDispatcher để vẽ bounding box cho hitbox phụ ==
package net.khangquach.practicemod.mixin;

import net.khangquach.practicemod.entity.custom.EntityHitboxData;
import net.khangquach.practicemod.entity.custom.MultiPart;
import net.khangquach.practicemod.entity.custom.MultiPartEntity;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityRenderDispatcher.class)
public class EntityRenderDispatcherMixin {

    @Inject(
            method = "renderHitbox",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/WorldRenderer;drawBox("
                            + "Lnet/minecraft/client/util/math/MatrixStack;"
                            + "Lnet/minecraft/client/render/VertexConsumer;"
                            + "Lnet/minecraft/util/math/Box;FFFF)V",
                    shift = At.Shift.AFTER
            )
    )
    private static void renderMultiPartHitbox(
            MatrixStack matrices, VertexConsumer vertices, Entity entity, float tickDelta, float red, float green, float blue, CallbackInfo ci
    ) {
        if (!(entity instanceof MultiPartEntity<?> multi)) return;

        EntityHitboxData<?> data = multi.getEntityHitboxData();

        if (data != null) {
            data.makeBoundingBoxForCulling();
        }

        assert data != null;
        for (MultiPart<?> part : data.getCustomParts()) {
            Entity partEntity = part.getEntity();

            double dx = -MathHelper.lerp(tickDelta, entity.prevX, entity.getX());
            double dy = -MathHelper.lerp(tickDelta, entity.prevY, entity.getY());
            double dz = -MathHelper.lerp(tickDelta, entity.prevZ, entity.getZ());

            double px = MathHelper.lerp(tickDelta, partEntity.prevX, partEntity.getX());
            double py = MathHelper.lerp(tickDelta, partEntity.prevY, partEntity.getY());
            double pz = MathHelper.lerp(tickDelta, partEntity.prevZ, partEntity.getZ());

            Box box = partEntity.getBoundingBox();
            matrices.push();
            matrices.translate(
                    box.minX + dx,
                    box.minY + dy,
                    box.minZ + dz
            );

            Box translatedBox = new Box(
                    0, 0, 0,
                    box.getLengthX(),
                    box.getLengthY(),
                    box.getLengthZ()
            );

            WorldRenderer.drawBox(matrices, vertices, translatedBox, 0.25f, 1.0f, 0.0f, 1.0f);
            matrices.pop();

        }
    }
}
