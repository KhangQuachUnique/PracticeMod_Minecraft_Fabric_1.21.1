package net.khangquach.practicemod.mixin;

import net.khangquach.practicemod.entity.custom.MultiPartEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

@Mixin(World.class)
public abstract class WorldMixin {

    @Inject(method = "getC",
            at = @At("HEAD"), cancellable = true)
    private void skipEntityCollisionForMultipart(Entity entity, Box box, CallbackInfoReturnable<List<VoxelShape>> cir) {
        if (entity instanceof MultiPartEntity<?>) {
            // Không tính va chạm với các entity khác (player, mob,...)
            cir.setReturnValue(List.of());
        }
    }
}

